var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./Gravatar/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./Gravatar/index.ts":
/*!***************************!*\
  !*** ./Gravatar/index.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar md5_typescript_1 = __webpack_require__(/*! md5-typescript */ \"./node_modules/md5-typescript/dist/index.js\");\n\nvar Gravatar =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function Gravatar() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object;\r\n   * It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user.\r\n   * Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard',\r\n   * it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  Gravatar.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this; // Add control initialization code\n\n\n    this._context = context;\n    this._container = container;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._textElementChanged = this.emailAddressChanged.bind(this);\n    this._value = \"\";\n\n    if (context.parameters.sampleProperty == null) {\n      this._value = \"\";\n    } else {\n      this._value = context.parameters.sampleProperty.raw == null ? \"\" : context.parameters.sampleProperty.raw;\n    }\n\n    this._textElement = document.createElement(\"input\");\n\n    this._textElement.setAttribute(\"type\", \"text\");\n\n    this._textElement.addEventListener(\"change\", this._textElementChanged);\n\n    this._textElement.setAttribute(\"value\", this._value);\n\n    this._textElement.setAttribute(\"class\", \"InputText\");\n\n    this._textElement.value = this._value;\n\n    this._textElement.addEventListener(\"focusin\", function () {\n      _this._textElement.className = \"InputTextFocused\";\n    });\n\n    this._textElement.addEventListener(\"focusout\", function () {\n      _this._textElement.className = \"InputText\";\n    });\n\n    this._imgElement = document.createElement(\"img\");\n\n    this._imgElement.setAttribute(\"src\", \"https://secure.gravatar.com/avatar/\" + md5_typescript_1.Md5.init(this._value.toLowerCase()));\n\n    this._imgElement.setAttribute(\"border\", \"2\");\n\n    this._container.appendChild(this._textElement);\n\n    this._container.appendChild(this._imgElement);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values,\r\n   * data-sets, global values such as container height and width, offline status,\r\n   *  control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object;\r\n   * It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  Gravatar.prototype.updateView = function (context) {\n    this._textElement.readOnly = context.mode.isControlDisabled;\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  Gravatar.prototype.getOutputs = function () {\n    return {\n      sampleProperty: this._value\n    };\n  };\n\n  Gravatar.prototype.emailAddressChanged = function (evt) {\n    this._value = this._textElement.value;\n\n    this._imgElement.setAttribute(\"src\", \"https://secure.gravatar.com/avatar/\" + md5_typescript_1.Md5.init(this._value.toLowerCase()));\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  Gravatar.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\t\t\n    this._textElement.removeEventListener(\"change\", this._textElementChanged);\n  };\n\n  return Gravatar;\n}();\n\nexports.Gravatar = Gravatar;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Gravatar/index.ts?");

/***/ }),

/***/ "./node_modules/md5-typescript/dist/index.js":
/*!***************************************************!*\
  !*** ./node_modules/md5-typescript/dist/index.js ***!
  \***************************************************/
/*! exports provided: Md5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"Md5\", function() { return Md5; });\nvar Md5 =\n/** @class */\nfunction () {\n  function Md5() {}\n\n  Md5.AddUnsigned = function (lX, lY) {\n    var lX4, lY4, lX8, lY8, lResult;\n    lX8 = lX & 0x80000000;\n    lY8 = lY & 0x80000000;\n    lX4 = lX & 0x40000000;\n    lY4 = lY & 0x40000000;\n    lResult = (lX & 0x3FFFFFFF) + (lY & 0x3FFFFFFF);\n\n    if (!!(lX4 & lY4)) {\n      return lResult ^ 0x80000000 ^ lX8 ^ lY8;\n    }\n\n    if (!!(lX4 | lY4)) {\n      if (!!(lResult & 0x40000000)) {\n        return lResult ^ 0xC0000000 ^ lX8 ^ lY8;\n      } else {\n        return lResult ^ 0x40000000 ^ lX8 ^ lY8;\n      }\n    } else {\n      return lResult ^ lX8 ^ lY8;\n    }\n  };\n\n  Md5.FF = function (a, b, c, d, x, s, ac) {\n    a = this.AddUnsigned(a, this.AddUnsigned(this.AddUnsigned(this.F(b, c, d), x), ac));\n    return this.AddUnsigned(this.RotateLeft(a, s), b);\n  };\n\n  Md5.GG = function (a, b, c, d, x, s, ac) {\n    a = this.AddUnsigned(a, this.AddUnsigned(this.AddUnsigned(this.G(b, c, d), x), ac));\n    return this.AddUnsigned(this.RotateLeft(a, s), b);\n  };\n\n  Md5.HH = function (a, b, c, d, x, s, ac) {\n    a = this.AddUnsigned(a, this.AddUnsigned(this.AddUnsigned(this.H(b, c, d), x), ac));\n    return this.AddUnsigned(this.RotateLeft(a, s), b);\n  };\n\n  Md5.II = function (a, b, c, d, x, s, ac) {\n    a = this.AddUnsigned(a, this.AddUnsigned(this.AddUnsigned(this.I(b, c, d), x), ac));\n    return this.AddUnsigned(this.RotateLeft(a, s), b);\n  };\n\n  Md5.ConvertToWordArray = function (string) {\n    var lWordCount,\n        lMessageLength = string.length,\n        lNumberOfWords_temp1 = lMessageLength + 8,\n        lNumberOfWords_temp2 = (lNumberOfWords_temp1 - lNumberOfWords_temp1 % 64) / 64,\n        lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16,\n        lWordArray = Array(lNumberOfWords - 1),\n        lBytePosition = 0,\n        lByteCount = 0;\n\n    while (lByteCount < lMessageLength) {\n      lWordCount = (lByteCount - lByteCount % 4) / 4;\n      lBytePosition = lByteCount % 4 * 8;\n      lWordArray[lWordCount] = lWordArray[lWordCount] | string.charCodeAt(lByteCount) << lBytePosition;\n      lByteCount++;\n    }\n\n    lWordCount = (lByteCount - lByteCount % 4) / 4;\n    lBytePosition = lByteCount % 4 * 8;\n    lWordArray[lWordCount] = lWordArray[lWordCount] | 0x80 << lBytePosition;\n    lWordArray[lNumberOfWords - 2] = lMessageLength << 3;\n    lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;\n    return lWordArray;\n  };\n\n  Md5.WordToHex = function (lValue) {\n    var WordToHexValue = \"\",\n        WordToHexValue_temp = \"\",\n        lByte,\n        lCount;\n\n    for (lCount = 0; lCount <= 3; lCount++) {\n      lByte = lValue >>> lCount * 8 & 255;\n      WordToHexValue_temp = \"0\" + lByte.toString(16);\n      WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length - 2, 2);\n    }\n\n    return WordToHexValue;\n  };\n\n  Md5.Utf8Encode = function (string) {\n    var utftext = \"\",\n        c;\n    string = string.replace(/\\r\\n/g, \"\\n\");\n\n    for (var n = 0; n < string.length; n++) {\n      c = string.charCodeAt(n);\n\n      if (c < 128) {\n        utftext += String.fromCharCode(c);\n      } else if (c > 127 && c < 2048) {\n        utftext += String.fromCharCode(c >> 6 | 192);\n        utftext += String.fromCharCode(c & 63 | 128);\n      } else {\n        utftext += String.fromCharCode(c >> 12 | 224);\n        utftext += String.fromCharCode(c >> 6 & 63 | 128);\n        utftext += String.fromCharCode(c & 63 | 128);\n      }\n    }\n\n    return utftext;\n  };\n\n  Md5.init = function (string) {\n    var temp;\n    if (typeof string !== 'string') string = JSON.stringify(string);\n    this._string = this.Utf8Encode(string);\n    this.x = this.ConvertToWordArray(this._string);\n    this.a = 0x67452301;\n    this.b = 0xEFCDAB89;\n    this.c = 0x98BADCFE;\n    this.d = 0x10325476;\n\n    for (this.k = 0; this.k < this.x.length; this.k += 16) {\n      this.AA = this.a;\n      this.BB = this.b;\n      this.CC = this.c;\n      this.DD = this.d;\n      this.a = this.FF(this.a, this.b, this.c, this.d, this.x[this.k], this.S11, 0xD76AA478);\n      this.d = this.FF(this.d, this.a, this.b, this.c, this.x[this.k + 1], this.S12, 0xE8C7B756);\n      this.c = this.FF(this.c, this.d, this.a, this.b, this.x[this.k + 2], this.S13, 0x242070DB);\n      this.b = this.FF(this.b, this.c, this.d, this.a, this.x[this.k + 3], this.S14, 0xC1BDCEEE);\n      this.a = this.FF(this.a, this.b, this.c, this.d, this.x[this.k + 4], this.S11, 0xF57C0FAF);\n      this.d = this.FF(this.d, this.a, this.b, this.c, this.x[this.k + 5], this.S12, 0x4787C62A);\n      this.c = this.FF(this.c, this.d, this.a, this.b, this.x[this.k + 6], this.S13, 0xA8304613);\n      this.b = this.FF(this.b, this.c, this.d, this.a, this.x[this.k + 7], this.S14, 0xFD469501);\n      this.a = this.FF(this.a, this.b, this.c, this.d, this.x[this.k + 8], this.S11, 0x698098D8);\n      this.d = this.FF(this.d, this.a, this.b, this.c, this.x[this.k + 9], this.S12, 0x8B44F7AF);\n      this.c = this.FF(this.c, this.d, this.a, this.b, this.x[this.k + 10], this.S13, 0xFFFF5BB1);\n      this.b = this.FF(this.b, this.c, this.d, this.a, this.x[this.k + 11], this.S14, 0x895CD7BE);\n      this.a = this.FF(this.a, this.b, this.c, this.d, this.x[this.k + 12], this.S11, 0x6B901122);\n      this.d = this.FF(this.d, this.a, this.b, this.c, this.x[this.k + 13], this.S12, 0xFD987193);\n      this.c = this.FF(this.c, this.d, this.a, this.b, this.x[this.k + 14], this.S13, 0xA679438E);\n      this.b = this.FF(this.b, this.c, this.d, this.a, this.x[this.k + 15], this.S14, 0x49B40821);\n      this.a = this.GG(this.a, this.b, this.c, this.d, this.x[this.k + 1], this.S21, 0xF61E2562);\n      this.d = this.GG(this.d, this.a, this.b, this.c, this.x[this.k + 6], this.S22, 0xC040B340);\n      this.c = this.GG(this.c, this.d, this.a, this.b, this.x[this.k + 11], this.S23, 0x265E5A51);\n      this.b = this.GG(this.b, this.c, this.d, this.a, this.x[this.k], this.S24, 0xE9B6C7AA);\n      this.a = this.GG(this.a, this.b, this.c, this.d, this.x[this.k + 5], this.S21, 0xD62F105D);\n      this.d = this.GG(this.d, this.a, this.b, this.c, this.x[this.k + 10], this.S22, 0x2441453);\n      this.c = this.GG(this.c, this.d, this.a, this.b, this.x[this.k + 15], this.S23, 0xD8A1E681);\n      this.b = this.GG(this.b, this.c, this.d, this.a, this.x[this.k + 4], this.S24, 0xE7D3FBC8);\n      this.a = this.GG(this.a, this.b, this.c, this.d, this.x[this.k + 9], this.S21, 0x21E1CDE6);\n      this.d = this.GG(this.d, this.a, this.b, this.c, this.x[this.k + 14], this.S22, 0xC33707D6);\n      this.c = this.GG(this.c, this.d, this.a, this.b, this.x[this.k + 3], this.S23, 0xF4D50D87);\n      this.b = this.GG(this.b, this.c, this.d, this.a, this.x[this.k + 8], this.S24, 0x455A14ED);\n      this.a = this.GG(this.a, this.b, this.c, this.d, this.x[this.k + 13], this.S21, 0xA9E3E905);\n      this.d = this.GG(this.d, this.a, this.b, this.c, this.x[this.k + 2], this.S22, 0xFCEFA3F8);\n      this.c = this.GG(this.c, this.d, this.a, this.b, this.x[this.k + 7], this.S23, 0x676F02D9);\n      this.b = this.GG(this.b, this.c, this.d, this.a, this.x[this.k + 12], this.S24, 0x8D2A4C8A);\n      this.a = this.HH(this.a, this.b, this.c, this.d, this.x[this.k + 5], this.S31, 0xFFFA3942);\n      this.d = this.HH(this.d, this.a, this.b, this.c, this.x[this.k + 8], this.S32, 0x8771F681);\n      this.c = this.HH(this.c, this.d, this.a, this.b, this.x[this.k + 11], this.S33, 0x6D9D6122);\n      this.b = this.HH(this.b, this.c, this.d, this.a, this.x[this.k + 14], this.S34, 0xFDE5380C);\n      this.a = this.HH(this.a, this.b, this.c, this.d, this.x[this.k + 1], this.S31, 0xA4BEEA44);\n      this.d = this.HH(this.d, this.a, this.b, this.c, this.x[this.k + 4], this.S32, 0x4BDECFA9);\n      this.c = this.HH(this.c, this.d, this.a, this.b, this.x[this.k + 7], this.S33, 0xF6BB4B60);\n      this.b = this.HH(this.b, this.c, this.d, this.a, this.x[this.k + 10], this.S34, 0xBEBFBC70);\n      this.a = this.HH(this.a, this.b, this.c, this.d, this.x[this.k + 13], this.S31, 0x289B7EC6);\n      this.d = this.HH(this.d, this.a, this.b, this.c, this.x[this.k], this.S32, 0xEAA127FA);\n      this.c = this.HH(this.c, this.d, this.a, this.b, this.x[this.k + 3], this.S33, 0xD4EF3085);\n      this.b = this.HH(this.b, this.c, this.d, this.a, this.x[this.k + 6], this.S34, 0x4881D05);\n      this.a = this.HH(this.a, this.b, this.c, this.d, this.x[this.k + 9], this.S31, 0xD9D4D039);\n      this.d = this.HH(this.d, this.a, this.b, this.c, this.x[this.k + 12], this.S32, 0xE6DB99E5);\n      this.c = this.HH(this.c, this.d, this.a, this.b, this.x[this.k + 15], this.S33, 0x1FA27CF8);\n      this.b = this.HH(this.b, this.c, this.d, this.a, this.x[this.k + 2], this.S34, 0xC4AC5665);\n      this.a = this.II(this.a, this.b, this.c, this.d, this.x[this.k], this.S41, 0xF4292244);\n      this.d = this.II(this.d, this.a, this.b, this.c, this.x[this.k + 7], this.S42, 0x432AFF97);\n      this.c = this.II(this.c, this.d, this.a, this.b, this.x[this.k + 14], this.S43, 0xAB9423A7);\n      this.b = this.II(this.b, this.c, this.d, this.a, this.x[this.k + 5], this.S44, 0xFC93A039);\n      this.a = this.II(this.a, this.b, this.c, this.d, this.x[this.k + 12], this.S41, 0x655B59C3);\n      this.d = this.II(this.d, this.a, this.b, this.c, this.x[this.k + 3], this.S42, 0x8F0CCC92);\n      this.c = this.II(this.c, this.d, this.a, this.b, this.x[this.k + 10], this.S43, 0xFFEFF47D);\n      this.b = this.II(this.b, this.c, this.d, this.a, this.x[this.k + 1], this.S44, 0x85845DD1);\n      this.a = this.II(this.a, this.b, this.c, this.d, this.x[this.k + 8], this.S41, 0x6FA87E4F);\n      this.d = this.II(this.d, this.a, this.b, this.c, this.x[this.k + 15], this.S42, 0xFE2CE6E0);\n      this.c = this.II(this.c, this.d, this.a, this.b, this.x[this.k + 6], this.S43, 0xA3014314);\n      this.b = this.II(this.b, this.c, this.d, this.a, this.x[this.k + 13], this.S44, 0x4E0811A1);\n      this.a = this.II(this.a, this.b, this.c, this.d, this.x[this.k + 4], this.S41, 0xF7537E82);\n      this.d = this.II(this.d, this.a, this.b, this.c, this.x[this.k + 11], this.S42, 0xBD3AF235);\n      this.c = this.II(this.c, this.d, this.a, this.b, this.x[this.k + 2], this.S43, 0x2AD7D2BB);\n      this.b = this.II(this.b, this.c, this.d, this.a, this.x[this.k + 9], this.S44, 0xEB86D391);\n      this.a = this.AddUnsigned(this.a, this.AA);\n      this.b = this.AddUnsigned(this.b, this.BB);\n      this.c = this.AddUnsigned(this.c, this.CC);\n      this.d = this.AddUnsigned(this.d, this.DD);\n    }\n\n    temp = this.WordToHex(this.a) + this.WordToHex(this.b) + this.WordToHex(this.c) + this.WordToHex(this.d);\n    return temp.toLowerCase();\n  };\n\n  Md5.x = Array();\n  Md5.S11 = 7;\n  Md5.S12 = 12;\n  Md5.S13 = 17;\n  Md5.S14 = 22;\n  Md5.S21 = 5;\n  Md5.S22 = 9;\n  Md5.S23 = 14;\n  Md5.S24 = 20;\n  Md5.S31 = 4;\n  Md5.S32 = 11;\n  Md5.S33 = 16;\n  Md5.S34 = 23;\n  Md5.S41 = 6;\n  Md5.S42 = 10;\n  Md5.S43 = 15;\n  Md5.S44 = 21;\n\n  Md5.RotateLeft = function (lValue, iShiftBits) {\n    return lValue << iShiftBits | lValue >>> 32 - iShiftBits;\n  };\n\n  Md5.F = function (x, y, z) {\n    return x & y | ~x & z;\n  };\n\n  Md5.G = function (x, y, z) {\n    return x & z | y & ~z;\n  };\n\n  Md5.H = function (x, y, z) {\n    return x ^ y ^ z;\n  };\n\n  Md5.I = function (x, y, z) {\n    return y ^ (x | ~z);\n  };\n\n  return Md5;\n}();\n\n\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/md5-typescript/dist/index.js?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MyPCFControl.Gravatar', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Gravatar);
} else {
	var MyPCFControl = MyPCFControl || {};
	MyPCFControl.Gravatar = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Gravatar;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}